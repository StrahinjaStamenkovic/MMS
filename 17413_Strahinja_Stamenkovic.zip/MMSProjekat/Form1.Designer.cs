﻿
namespace MMSProjekat
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filtersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.switchChannelsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.switchBetweenGrayscaleAndCmyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.invertToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gammaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.randomJitterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.edgeDetectDifferenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.embossLaplacianToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clampChannelValuesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorizeGrayscaleChannelsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.defaultMappingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mapAccordingToImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.crossdomainColorizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orderedDitheringToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.floydSteinbergDitherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stuckiDitherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kuwaharaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.safeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unsafeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enableUnsafeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enableConvValuesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.undoRedoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.downsampleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadCompressedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.filtersToolStripMenuItem,
            this.optionsToolStripMenuItem,
            this.undoRedoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(686, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadToolStripMenuItem,
            this.loadCompressedToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.loadToolStripMenuItem.Text = "Load";
            this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // filtersToolStripMenuItem
            // 
            this.filtersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showToolStripMenuItem,
            this.switchChannelsToolStripMenuItem,
            this.switchBetweenGrayscaleAndCmyToolStripMenuItem,
            this.invertToolStripMenuItem,
            this.gammaToolStripMenuItem,
            this.randomJitterToolStripMenuItem,
            this.edgeDetectDifferenceToolStripMenuItem,
            this.embossLaplacianToolStripMenuItem,
            this.clampChannelValuesToolStripMenuItem,
            this.colorizeGrayscaleChannelsToolStripMenuItem,
            this.crossdomainColorizeToolStripMenuItem,
            this.orderedDitheringToolStripMenuItem,
            this.floydSteinbergDitherToolStripMenuItem,
            this.stuckiDitherToolStripMenuItem,
            this.kuwaharaToolStripMenuItem,
            this.downsampleToolStripMenuItem});
            this.filtersToolStripMenuItem.Name = "filtersToolStripMenuItem";
            this.filtersToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.filtersToolStripMenuItem.Text = "Filters";
            // 
            // showToolStripMenuItem
            // 
            this.showToolStripMenuItem.Name = "showToolStripMenuItem";
            this.showToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.showToolStripMenuItem.Text = "Show CMY";
            this.showToolStripMenuItem.Click += new System.EventHandler(this.showToolStripMenuItem_Click);
            // 
            // switchChannelsToolStripMenuItem
            // 
            this.switchChannelsToolStripMenuItem.Name = "switchChannelsToolStripMenuItem";
            this.switchChannelsToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.switchChannelsToolStripMenuItem.Text = "Switch to histograms";
            this.switchChannelsToolStripMenuItem.Click += new System.EventHandler(this.switchChannelsToolStripMenuItem_Click);
            // 
            // switchBetweenGrayscaleAndCmyToolStripMenuItem
            // 
            this.switchBetweenGrayscaleAndCmyToolStripMenuItem.Name = "switchBetweenGrayscaleAndCmyToolStripMenuItem";
            this.switchBetweenGrayscaleAndCmyToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.switchBetweenGrayscaleAndCmyToolStripMenuItem.Text = "Switch to grayscale";
            this.switchBetweenGrayscaleAndCmyToolStripMenuItem.Click += new System.EventHandler(this.switchBetweenGrayscaleAndCMYToolStripMenuItem_Click);
            // 
            // invertToolStripMenuItem
            // 
            this.invertToolStripMenuItem.Name = "invertToolStripMenuItem";
            this.invertToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.invertToolStripMenuItem.Text = "Invert";
            this.invertToolStripMenuItem.Click += new System.EventHandler(this.invertToolStripMenuItem_Click);
            // 
            // gammaToolStripMenuItem
            // 
            this.gammaToolStripMenuItem.Name = "gammaToolStripMenuItem";
            this.gammaToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.gammaToolStripMenuItem.Text = "Gamma";
            this.gammaToolStripMenuItem.Click += new System.EventHandler(this.gammaToolStripMenuItem_Click);
            // 
            // randomJitterToolStripMenuItem
            // 
            this.randomJitterToolStripMenuItem.Name = "randomJitterToolStripMenuItem";
            this.randomJitterToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.randomJitterToolStripMenuItem.Text = "Random jitter";
            this.randomJitterToolStripMenuItem.Click += new System.EventHandler(this.randomJitterToolStripMenuItem_Click);
            // 
            // edgeDetectDifferenceToolStripMenuItem
            // 
            this.edgeDetectDifferenceToolStripMenuItem.Name = "edgeDetectDifferenceToolStripMenuItem";
            this.edgeDetectDifferenceToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.edgeDetectDifferenceToolStripMenuItem.Text = "Edge detect difference";
            this.edgeDetectDifferenceToolStripMenuItem.Click += new System.EventHandler(this.edgeDetectDifferenceToolStripMenuItem_Click);
            // 
            // embossLaplacianToolStripMenuItem
            // 
            this.embossLaplacianToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.x3ToolStripMenuItem,
            this.x5ToolStripMenuItem,
            this.x7ToolStripMenuItem});
            this.embossLaplacianToolStripMenuItem.Name = "embossLaplacianToolStripMenuItem";
            this.embossLaplacianToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.embossLaplacianToolStripMenuItem.Text = "Emboss Laplacian";
            // 
            // x3ToolStripMenuItem
            // 
            this.x3ToolStripMenuItem.Name = "x3ToolStripMenuItem";
            this.x3ToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.x3ToolStripMenuItem.Text = "3x3";
            this.x3ToolStripMenuItem.Click += new System.EventHandler(this.x3ToolStripMenuItem_Click);
            // 
            // x5ToolStripMenuItem
            // 
            this.x5ToolStripMenuItem.Name = "x5ToolStripMenuItem";
            this.x5ToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.x5ToolStripMenuItem.Text = "5x5";
            this.x5ToolStripMenuItem.Click += new System.EventHandler(this.x5ToolStripMenuItem_Click);
            // 
            // x7ToolStripMenuItem
            // 
            this.x7ToolStripMenuItem.Name = "x7ToolStripMenuItem";
            this.x7ToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.x7ToolStripMenuItem.Text = "7x7";
            this.x7ToolStripMenuItem.Click += new System.EventHandler(this.x7ToolStripMenuItem_Click);
            // 
            // clampChannelValuesToolStripMenuItem
            // 
            this.clampChannelValuesToolStripMenuItem.Name = "clampChannelValuesToolStripMenuItem";
            this.clampChannelValuesToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.clampChannelValuesToolStripMenuItem.Text = "Clamp channel values";
            this.clampChannelValuesToolStripMenuItem.Click += new System.EventHandler(this.clampChannelValuesToolStripMenuItem_Click);
            // 
            // colorizeGrayscaleChannelsToolStripMenuItem
            // 
            this.colorizeGrayscaleChannelsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.defaultMappingToolStripMenuItem,
            this.mapAccordingToImageToolStripMenuItem});
            this.colorizeGrayscaleChannelsToolStripMenuItem.Name = "colorizeGrayscaleChannelsToolStripMenuItem";
            this.colorizeGrayscaleChannelsToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.colorizeGrayscaleChannelsToolStripMenuItem.Text = "Colorize grayscale channels";
            // 
            // defaultMappingToolStripMenuItem
            // 
            this.defaultMappingToolStripMenuItem.Name = "defaultMappingToolStripMenuItem";
            this.defaultMappingToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.defaultMappingToolStripMenuItem.Text = "Default mapping";
            this.defaultMappingToolStripMenuItem.Click += new System.EventHandler(this.defaultMappingToolStripMenuItem_Click);
            // 
            // mapAccordingToImageToolStripMenuItem
            // 
            this.mapAccordingToImageToolStripMenuItem.Name = "mapAccordingToImageToolStripMenuItem";
            this.mapAccordingToImageToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.mapAccordingToImageToolStripMenuItem.Text = "Map according to image";
            this.mapAccordingToImageToolStripMenuItem.Click += new System.EventHandler(this.mapAccordingToImageToolStripMenuItem_Click);
            // 
            // crossdomainColorizeToolStripMenuItem
            // 
            this.crossdomainColorizeToolStripMenuItem.Name = "crossdomainColorizeToolStripMenuItem";
            this.crossdomainColorizeToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.crossdomainColorizeToolStripMenuItem.Text = "Cross-domain colorize";
            this.crossdomainColorizeToolStripMenuItem.Click += new System.EventHandler(this.crossdomainColorizeToolStripMenuItem_Click);
            // 
            // orderedDitheringToolStripMenuItem
            // 
            this.orderedDitheringToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.x2ToolStripMenuItem,
            this.x4ToolStripMenuItem,
            this.x8ToolStripMenuItem});
            this.orderedDitheringToolStripMenuItem.Name = "orderedDitheringToolStripMenuItem";
            this.orderedDitheringToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.orderedDitheringToolStripMenuItem.Text = "Ordered dithering";
            // 
            // x2ToolStripMenuItem
            // 
            this.x2ToolStripMenuItem.Name = "x2ToolStripMenuItem";
            this.x2ToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.x2ToolStripMenuItem.Text = "2x2";
            this.x2ToolStripMenuItem.Click += new System.EventHandler(this.x2ToolStripMenuItem_Click);
            // 
            // x4ToolStripMenuItem
            // 
            this.x4ToolStripMenuItem.Name = "x4ToolStripMenuItem";
            this.x4ToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.x4ToolStripMenuItem.Text = "4x4";
            this.x4ToolStripMenuItem.Click += new System.EventHandler(this.x4ToolStripMenuItem_Click);
            // 
            // x8ToolStripMenuItem
            // 
            this.x8ToolStripMenuItem.Name = "x8ToolStripMenuItem";
            this.x8ToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.x8ToolStripMenuItem.Text = "8x8";
            this.x8ToolStripMenuItem.Click += new System.EventHandler(this.x8ToolStripMenuItem_Click);
            // 
            // floydSteinbergDitherToolStripMenuItem
            // 
            this.floydSteinbergDitherToolStripMenuItem.Name = "floydSteinbergDitherToolStripMenuItem";
            this.floydSteinbergDitherToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.floydSteinbergDitherToolStripMenuItem.Text = "Floyd-Steinberg dither";
            this.floydSteinbergDitherToolStripMenuItem.Click += new System.EventHandler(this.floydSteinbergDitherToolStripMenuItem_Click);
            // 
            // stuckiDitherToolStripMenuItem
            // 
            this.stuckiDitherToolStripMenuItem.Name = "stuckiDitherToolStripMenuItem";
            this.stuckiDitherToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.stuckiDitherToolStripMenuItem.Text = "Stucki dither";
            this.stuckiDitherToolStripMenuItem.Click += new System.EventHandler(this.stuckiDitherToolStripMenuItem_Click);
            // 
            // kuwaharaToolStripMenuItem
            // 
            this.kuwaharaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.safeToolStripMenuItem,
            this.unsafeToolStripMenuItem});
            this.kuwaharaToolStripMenuItem.Name = "kuwaharaToolStripMenuItem";
            this.kuwaharaToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.kuwaharaToolStripMenuItem.Text = "Kuwahara";
            // 
            // safeToolStripMenuItem
            // 
            this.safeToolStripMenuItem.Name = "safeToolStripMenuItem";
            this.safeToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.safeToolStripMenuItem.Text = "Safe";
            this.safeToolStripMenuItem.Click += new System.EventHandler(this.safeToolStripMenuItem_Click);
            // 
            // unsafeToolStripMenuItem
            // 
            this.unsafeToolStripMenuItem.Name = "unsafeToolStripMenuItem";
            this.unsafeToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.unsafeToolStripMenuItem.Text = "Unsafe";
            this.unsafeToolStripMenuItem.Click += new System.EventHandler(this.unsafeToolStripMenuItem_Click);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enableUnsafeToolStripMenuItem,
            this.enableConvValuesToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // enableUnsafeToolStripMenuItem
            // 
            this.enableUnsafeToolStripMenuItem.Name = "enableUnsafeToolStripMenuItem";
            this.enableUnsafeToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.enableUnsafeToolStripMenuItem.Text = "Enable unsafe methods";
            this.enableUnsafeToolStripMenuItem.Click += new System.EventHandler(this.useUnsafeToolStripMenuItem_Click);
            // 
            // enableConvValuesToolStripMenuItem
            // 
            this.enableConvValuesToolStripMenuItem.Name = "enableConvValuesToolStripMenuItem";
            this.enableConvValuesToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.enableConvValuesToolStripMenuItem.Text = "Enable conv. values";
            this.enableConvValuesToolStripMenuItem.Click += new System.EventHandler(this.enableConvValuesToolStripMenuItem_Click);
            // 
            // undoRedoToolStripMenuItem
            // 
            this.undoRedoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem,
            this.redoToolStripMenuItem,
            this.settingsToolStripMenuItem});
            this.undoRedoToolStripMenuItem.Name = "undoRedoToolStripMenuItem";
            this.undoRedoToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.undoRedoToolStripMenuItem.Text = "Undo-Redo";
            // 
            // undoToolStripMenuItem
            // 
            this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            this.undoToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.undoToolStripMenuItem.Text = "Undo";
            this.undoToolStripMenuItem.Click += new System.EventHandler(this.undoToolStripMenuItem_Click);
            // 
            // redoToolStripMenuItem
            // 
            this.redoToolStripMenuItem.Name = "redoToolStripMenuItem";
            this.redoToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.redoToolStripMenuItem.Text = "Redo";
            this.redoToolStripMenuItem.Click += new System.EventHandler(this.redoToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.settingsToolStripMenuItem.Text = "Settings";
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            // 
            // chart1
            // 
            chartArea4.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.chart1.Legends.Add(legend4);
            this.chart1.Location = new System.Drawing.Point(306, 27);
            this.chart1.Name = "chart1";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Area;
            series4.Legend = "Legend1";
            series4.Name = "Cyan";
            this.chart1.Series.Add(series4);
            this.chart1.Size = new System.Drawing.Size(300, 235);
            this.chart1.TabIndex = 1;
            this.chart1.Text = "chart1";
            this.chart1.Visible = false;
            // 
            // chart2
            // 
            chartArea5.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea5);
            legend5.Name = "Legend1";
            this.chart2.Legends.Add(legend5);
            this.chart2.Location = new System.Drawing.Point(0, 268);
            this.chart2.Name = "chart2";
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Area;
            series5.Legend = "Legend1";
            series5.Name = "Magenta";
            this.chart2.Series.Add(series5);
            this.chart2.Size = new System.Drawing.Size(300, 300);
            this.chart2.TabIndex = 2;
            this.chart2.Text = "chart2";
            this.chart2.Visible = false;
            // 
            // chart3
            // 
            chartArea6.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea6);
            legend6.Name = "Legend1";
            this.chart3.Legends.Add(legend6);
            this.chart3.Location = new System.Drawing.Point(306, 268);
            this.chart3.Name = "chart3";
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Area;
            series6.Legend = "Legend1";
            series6.Name = "Yellow";
            this.chart3.Series.Add(series6);
            this.chart3.Size = new System.Drawing.Size(300, 300);
            this.chart3.TabIndex = 3;
            this.chart3.Text = "chart3";
            this.chart3.Visible = false;
            // 
            // downsampleToolStripMenuItem
            // 
            this.downsampleToolStripMenuItem.Name = "downsampleToolStripMenuItem";
            this.downsampleToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.downsampleToolStripMenuItem.Text = "Downsample";
            this.downsampleToolStripMenuItem.Click += new System.EventHandler(this.downsampleToolStripMenuItem_Click);
            // 
            // loadCompressedToolStripMenuItem
            // 
            this.loadCompressedToolStripMenuItem.Name = "loadCompressedToolStripMenuItem";
            this.loadCompressedToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.loadCompressedToolStripMenuItem.Text = "Load compressed";
            this.loadCompressedToolStripMenuItem.Click += new System.EventHandler(this.loadCompressedToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(686, 390);
            this.Controls.Add(this.chart3);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filtersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enableUnsafeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem undoRedoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem invertToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem embossLaplacianToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gammaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enableConvValuesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem randomJitterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem edgeDetectDifferenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem switchChannelsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clampChannelValuesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem switchBetweenGrayscaleAndCmyToolStripMenuItem;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.ToolStripMenuItem orderedDitheringToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem floydSteinbergDitherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorizeGrayscaleChannelsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem defaultMappingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mapAccordingToImageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stuckiDitherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem crossdomainColorizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kuwaharaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem safeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unsafeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem downsampleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadCompressedToolStripMenuItem;
    }
}

